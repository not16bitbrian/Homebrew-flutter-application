package com.example.homebrew

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
