import 'package:flutter/material.dart';
import 'choose_french_screen.dart';
import 'choose_drip_screen.dart';

class ChooseDeviceScreen extends StatefulWidget {
  @override
  _ChooseDeviceScreenState createState() => _ChooseDeviceScreenState();
}

class _ChooseDeviceScreenState extends State<ChooseDeviceScreen> {
  bool _agreed = false;

  List<bool> isSelected = List.generate(2, (_) => false);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xfff3f3f3),
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Row(mainAxisAlignment: MainAxisAlignment.center, children: [
                Text(
                  "What coffee maker are you using?",
                  key: Key('device-screen'),
                  style: TextStyle(
                      fontFamily: 'montserrat',
                      fontSize: 18,
                      color: Color(0xff4c748b),
                      fontWeight: FontWeight.w400),
                ),
              ]),
              Padding(padding: const EdgeInsets.all(12.0)),
              Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                ToggleButtons(
                  children: <Widget>[
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 25.0, right: 210.0),
                          child: Text(
                            'French Press',
                            key: Key('french-option'),
                            style: TextStyle(
                                color: Color(0xff4c748b),
                                fontFamily: 'montserrat',
                                fontSize: 14,
                                fontWeight: FontWeight.w500),
                          ),
                        ),
                        Icon(
                          Icons.check,
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Padding(
                          padding: EdgeInsets.only(left: 25.0, right: 207.0),
                          child: Text('Drip Machine',
                              key: Key('drip-option'),
                              style: TextStyle(
                                  color: Color(0xff4c748b),
                                  fontFamily: 'montserrat',
                                  fontSize: 14,
                                  fontWeight: FontWeight.w500)),
                        ),
                        Icon(
                          Icons.check,
                        ),
                      ],
                    )
                  ],
                  constraints: BoxConstraints(minWidth: 370, minHeight: 47),
                  color: Color(0xfff3f3f3), //f3f3f3
                  direction: Axis.vertical,
                  selectedColor: Color(0xff4c748b),
                  fillColor: Color(0xfff3f3f3),
                  borderRadius: BorderRadius.circular(10.0),
                  borderColor: Color(0xff4c748b),
                  selectedBorderColor: Color(0xff4c748b),
                  borderWidth: 2,
                  isSelected: isSelected,
                  onPressed: (int index) {
                    setState(() {
                      for (int i = 0; i < isSelected.length; i++) {
                        isSelected[i] = i == index;
                        _agreed = true;
                      }
                    });
                  },
                ),
                Padding(padding: const EdgeInsets.all(10.0)),
                ElevatedButton(
                    onPressed: _agreed
                        ? () {
                            if (isSelected[0] == true) {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ChooseCupsFrenchScreen()));
                            } else {
                              Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                      builder: (context) =>
                                          ChooseCupsDripScreen()));
                            }
                          }
                        : null,
                    child: Text('Continue',
                        key: Key('continue-button'),
                        style:
                            TextStyle(fontFamily: 'montserrat', fontSize: 14, fontWeight: FontWeight.w400)),
                    style: ElevatedButton.styleFrom(
                        shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(20.0)),
                        minimumSize: Size(280, 46),
                        primary: Color(0xff4c748b),
                        onPrimary: Color(0xffffffff))),
              ]),
            ],
          ),
        ));
  }
}