import 'package:flutter/material.dart';
import 'choose_device_screen.dart';
import 'final_french_screen.dart';

class ChooseCupsFrenchScreen extends StatefulWidget {
  @override
  _ChooseCupsFrenchScreenState createState() => _ChooseCupsFrenchScreenState();
}

class _ChooseCupsFrenchScreenState extends State<ChooseCupsFrenchScreen> {


  TextEditingController numCups = TextEditingController();
  bool btnEnabled = false;
  bool isEmpty() {
    setState(() {
      int cups = int.parse(numCups.text);
      if (cups != null && cups > 0) {
        btnEnabled = true;
      } else
        btnEnabled = false;
    });
    return btnEnabled;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xfff3f3f3),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
      floatingActionButton: FloatingActionButton(
        key: Key('back-button'),
        child: Icon(Icons.arrow_back_ios),
        foregroundColor: Color(0xff4c748b),
        backgroundColor: Color(0xfff3f3f3),
        mini: true,
        elevation: 0,
        onPressed: () {
          Navigator.pop(context,
              MaterialPageRoute(builder: (context) => ChooseDeviceScreen()));
        },
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              Text(
                "How many cups would you like?",
                key: Key('cups-message'),
                style: TextStyle(
                    fontFamily: 'montserrat',
                    fontSize: 18,
                    color: Color(0xff4c748b)),
              ),
            ]),
            Padding(padding: const EdgeInsets.all(10.0)),
            ConstrainedBox(
              constraints: BoxConstraints.tightFor(width: 337, height: 48),
              child: TextField(
                onChanged: (val) {
                  isEmpty();
                },
                controller: numCups,
                key: Key('cups-french-text-field'),
                decoration: InputDecoration(
                    enabledBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff4c748b), width: 2.0),
                        borderRadius: BorderRadius.circular(10.0)),
                    focusedBorder: OutlineInputBorder(
                        borderSide:
                            BorderSide(color: Color(0xff4c748b), width: 2.0),
                        borderRadius: BorderRadius.circular(10.0))),
              ),
            ),
            Padding(padding: const EdgeInsets.all(10.0)),
            ElevatedButton(
                onPressed: btnEnabled
                    ? () {
                        Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (context) =>
                                    FinalScreenFrench(water: numCups.text)));
                      }
                    : null,
                child: Text('Continue',
                    key: Key('continue-french-button'),
                    style: TextStyle(fontFamily: 'montserrat', fontSize: 14)),
                style: ElevatedButton.styleFrom(
                    shape: new RoundedRectangleBorder(
                        borderRadius: new BorderRadius.circular(20.0)),
                    minimumSize: Size(280, 46),
                    primary: Color(0xff4c748b),
                    onPrimary: Color(0xffffffff))),
          ],
        ),
      ),
    );
  }
}