import 'package:flutter/material.dart';
import 'package:homebrew/screens/choose_device_screen.dart';
import 'package:homebrew/screens/choose_french_screen.dart';
import 'package:homebrew/utils/coffee_tools.dart';

class FinalScreenFrench extends StatefulWidget {
  final String water;
  FinalScreenFrench({Key key, this.water}) : super(key: key);
  @override
  _FinalScreenFrenchState createState() => _FinalScreenFrenchState();
}

class _FinalScreenFrenchState extends State<FinalScreenFrench> {
  @override
  Widget build(BuildContext context) {
    int water = int.parse(widget.water);
    double grams_of_water = CoffeeTools.cupsToGrams(water);
    double resultFrench = CoffeeTools.frenchpresscoffee(grams_of_water);

    return Scaffold(
      backgroundColor: Color(0xfff3f3f3),
      floatingActionButtonLocation: FloatingActionButtonLocation.miniStartTop,
      floatingActionButton: FloatingActionButton(
        key: Key('back-button'),
        child: Icon(Icons.arrow_back_ios),
        foregroundColor: Color(0xff4c748b),
        backgroundColor: Color(0xfff3f3f3),
        mini: true,
        elevation: 0,
        onPressed: () {
          Navigator.pop(
              context,
              MaterialPageRoute(
                  builder: (context) => ChooseCupsFrenchScreen()));
        },
      ),
      body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            SizedBox(
              height: 212,
            ),
            Container(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Padding(padding: const EdgeInsets.all(5.0)),
                  Text(
                    "Recommended",
                    style: TextStyle(
                        fontFamily: 'kollektif',
                        fontSize: 18,
                        color: Color(0xff4c748b),
                        fontWeight: FontWeight.w400),
                  ),
                  Divider(
                    color: Color(0xff4c748b),
                    thickness: 1,
                    indent: 20,
                    endIndent: 20,
                  ),
                  Padding(padding: const EdgeInsets.all(10.0)),
                  Text(
                    "${resultFrench.round()}g - course ground coffee",
                    key: Key('french-recommend-coffee'),
                    style: TextStyle(
                        fontFamily: 'kollektif',
                        fontSize: 14,
                        color: Color(0xff4c748b),
                        fontWeight: FontWeight.w400),
                  ),
                  Text(
                    "${grams_of_water.round()}g - water",
                    key: Key('french-recommend-water'),
                    style: TextStyle(
                        fontFamily: 'kollektif',
                        fontSize: 14,
                        color: Color(0xff4c748b),
                        fontWeight: FontWeight.w400),
                  ),
                  Padding(padding: const EdgeInsets.all(20.0)),
                  Text(
                    "Enjoy your delicious coffee.",
                    style: TextStyle(
                        fontFamily: 'montserrat',
                        fontSize: 10,
                        fontStyle: FontStyle.italic,
                        color: Color(0xff4c748b)),
                  ),
                ],
              ),
              width: 337,
              height: 164,
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(10.0),
                  border: Border.all(color: Color(0xff4c748b), width: 2)),
            ),
            Expanded(
              child: Align(
                alignment: FractionalOffset.bottomCenter,
                child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => ChooseDeviceScreen()));
                    },
                    child: Text('Done',
                        key: Key('done-button'),
                        style:
                            TextStyle(fontFamily: 'montserrat', fontSize: 14)),
                    style: ElevatedButton.styleFrom(
                        shape: new RoundedRectangleBorder(
                            borderRadius: new BorderRadius.circular(10.0)),
                        minimumSize: Size(280, 46),
                        primary: Color(0xff4c748b),
                        onPrimary: Color(0xffffffff))),
              ),
            ),
            Padding(padding: const EdgeInsets.fromLTRB(0, 25, 0, 0)),
          ]),
    );
  }
}