class CoffeeTools {
  // Input: number of cups (positive integer)
  // Output: number of ounces in a cup
  static int cupsToOunces(int cups) {
    if (cups <= 0) {
      throw ArgumentError();
    }
    return cups * 6;
  }

  static cupsToGrams(int water) {
    if (water <= 0) {
      throw ArgumentError();
    }
    double grams_of_water = water * 177.42;
    return grams_of_water;
    }

  static dripmachinecoffee(double grams_of_water) {
    if (grams_of_water <= 0) {
      throw ArgumentError();
    }
    double drip_grounds = grams_of_water / 17;
    return drip_grounds;
    }

  static frenchpresscoffee(double grams_of_water) {
    if (grams_of_water <= 0) {
      throw ArgumentError();
    }
    double french_grounds = grams_of_water / 14;
    return french_grounds;
    }
}
