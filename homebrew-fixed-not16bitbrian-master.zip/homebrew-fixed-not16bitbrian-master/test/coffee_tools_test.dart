import 'package:homebrew/utils/coffee_tools.dart';
import 'package:test/test.dart';
void main() {
  group("cupsToOunces", () {
    test('calculates ounces on 1 cup', () {
      var ounces = CoffeeTools.cupsToOunces(1);
      expect(ounces, 6);
    });
    test('calculates ounces on positive number of cups', () {
      var ounces = CoffeeTools.cupsToOunces(4);
      expect(ounces, 24);
    });
    test('throws ArgumentError on zero', () {
      expect(() => CoffeeTools.cupsToOunces(0), throwsArgumentError);
    });

    test('throws ArgumentError on negative number', () {
      expect(() => CoffeeTools.cupsToOunces(-1), throwsArgumentError);
    });
  });

    group("cupsToGrams", () {
    test('calculates grams on 1 cup', () {
      var grams = CoffeeTools.cupsToGrams(1);
      expect(grams, 177.42);
    });

    test('calculates grams on positive number of cups', () {
      var grams = CoffeeTools.cupsToGrams(4);
      expect(grams, 709.68);
    });

    test('throws ArgumentError on zero', () {
      expect(() => CoffeeTools.cupsToGrams(0), throwsArgumentError);
    });

    test('throws ArgumentError on negative number', () {
      expect(() => CoffeeTools.cupsToGrams(-1), throwsArgumentError);
    });
  });

    group("dripmachinecoffee", () {
    test('calculates amount of grams of medium grounds for 1 cup', () {
      var grounds = CoffeeTools.dripmachinecoffee(177.42);
      expect(grounds, 10.436470588235293);
    });

    test('calculates grams on positive number of cups', () {
      var grounds = CoffeeTools.dripmachinecoffee(680);
      expect(grounds, 40);
    });

    test('throws ArgumentError on zero', () {
      expect(() => CoffeeTools.dripmachinecoffee(0), throwsArgumentError);
    });

    test('throws ArgumentError on negative number', () {
      expect(() => CoffeeTools.dripmachinecoffee(-1), throwsArgumentError);
    });
  });

    group("frenchpresscoffee", () {
    test('calculates amount of grams of course grounds for 1 cup', () {
      var grounds = CoffeeTools.frenchpresscoffee(177.42);
      expect(grounds, 12.672857142857142);
    });

    test('calculates grams on positive number of cups', () {
      var grounds = CoffeeTools.frenchpresscoffee(560);
      expect(grounds, 40);
    });

    test('throws ArgumentError on zero', () {
      expect(() => CoffeeTools.frenchpresscoffee(0), throwsArgumentError);
    });

    test('throws ArgumentError on negative number', () {
      expect(() => CoffeeTools.frenchpresscoffee(-1), throwsArgumentError);
    });
  });
}