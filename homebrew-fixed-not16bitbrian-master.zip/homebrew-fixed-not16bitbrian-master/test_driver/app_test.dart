// Imports the Flutter Driver API.
import 'package:flutter_driver/flutter_driver.dart';
import 'package:test/test.dart';

void main() {
  FlutterDriver driver;

  // Connect to the Flutter driver before running any tests.
  setUpAll(() async {
    driver = await FlutterDriver.connect();
  });

  // Close the connection to the driver after the tests have completed.
  tearDownAll(() async {
    if (driver != null) {
      driver.close();
    }
  });
  group('Happy Paths', () {
    /*
      Given I am on the Coffee Device Selection Screen
      When I tap "French Press"
      And I tap "Continue"
      And I enter "5"
      And I tap "Continue"
      Then I should see "63g - course ground coffee"
      And I should see "887g - water"
    */

    test("should give recommendation for French Press", () async {
      // final frenchPressCoffee =find.byValueKey('french-option');
      // await driver.tap(frenchPressCoffee);
      // final nextPageContinue = find.byValueKey('continue-button');
      // await driver.tap(nextPageContinue);

      // final cups = find.byValueKey('cups-french-text-field');
      // await driver.tap(cups);
      // await driver.enterText('5');
      // await driver.waitFor(find.text('5'));
      // final gotofinalfrenchscreen = find.byValueKey('continue-french-button');
      // await driver.tap(gotofinalfrenchscreen);

      // final recCoffee =find.byValueKey('french-recommend-coffee');
      // final recWater = find.byValueKey('french-recommend-water');
      // expect(await driver.getText(recCoffee), '63g - course ground coffee');
      // expect(await driver.getText(recWater), '887g - water');
      // final done = find.byValueKey('done-button');
      // await driver.tap(done);
    });

    /*
      Given I am on the Coffee Device Selection Screen
      When I tap "Drip Machine"
      And I tap "Continue"
      And I enter "5"
      And I tap "Continue"
      Then I should see "52g - medium ground coffee"
      And I should see "887g - water"
    */
    test("should give recommendation for Drip Machine", () async {

      // final dripMachineCoffee =find.byValueKey('drip-option');
      // await driver.tap(dripMachineCoffee);
      // final nextPageConitnue = find.byValueKey('continue-button');
      // await driver.tap(nextPageConitnue);

      // final cups = find.byValueKey('cups-drip-text-field');
      // await driver.tap(cups);
      // await driver.enterText('5');
      // await driver.waitFor(find.text('5'));
      // final gotofinaldripscreen = find.byValueKey('continue-drip-button');
      // await driver.tap(gotofinaldripscreen);

      // final recCoffee =find.byValueKey('drip-recommend-coffee');
      // final recWater = find.byValueKey('drip-recommend-water');
      // expect(await driver.getText(recCoffee), '52g - medium ground coffee');
      // expect(await driver.getText(recWater), '887g - water');
      // final done = find.byValueKey('done-button');
      // await driver.tap(done);
    });

  });

  group('Sad Paths', () {
    /*
      Given I am on the Coffee Device Selection Screen
      When I press "Continue"
      Then I expect to still be on the Coffee Device Selection Screen
    */
    test("should not advance from Choose Device Screen without a selection",
        () async {
      // final nextPageConitnue = find.byValueKey('continue-button');
      // await driver.tap(nextPageConitnue);
      // final chooseDeviceScreen = find.byValueKey('device-screen');
      // expect(await driver.getText(chooseDeviceScreen), 'What coffee maker are you using?');
    });

    /*
      Given I chose "French Press" on the Coffee Device Selection Screen
      And I advanced to the Choose Cups Screen
      When I press "Continue"
      Then I expect to still be on the Choose Cups Screen
    */
    test("should not advance from Choose Cups Screen without cups", () async {
      // final frenchPressCoffee =find.byValueKey('french-option');
      // await driver.tap(frenchPressCoffee);
      // final nextPageConitnue = find.byValueKey('continue-button');
      // await driver.tap(nextPageConitnue);

      // final gotofinalfrenchscreen = find.byValueKey('continue-french-button');
      // await driver.tap(gotofinalfrenchscreen);
      // final cupsScreen = find.byValueKey('cups-message');
      // expect(await driver.getText(cupsScreen), 'How many cups would you like?');
    });

    /*
      Given I chose "French Press" on the Coffee Device Selection Screen
      And I advanced to the Choose Cups Screen
      When I enter "-1"
      And I press "Continue"
      Then I expect to still be on the Choose Cups Screen
    */
    test("should not advance from Choose Cups Screen with negative cup amount",
        () async {
      // final cups = find.byValueKey('cups-french-text-field');
      // await driver.tap(cups);
      // await driver.enterText('-1');
      // await driver.waitFor(find.text('-1'));
      // final gotofinalfrenchscreen = find.byValueKey('continue-french-button');
      // await driver.tap(gotofinalfrenchscreen);

      // final cupsScreen = find.byValueKey('cups-message');
      // expect(await driver.getText(cupsScreen), 'How many cups would you like?');
    });

    /*
      Given I chose "French Press" on the Coffee Device Selection Screen
      And I advanced to the Choose Cups Screen
      When I enter "a"
      And I press "Continue"
      Then I expect to still be on the Choose Cups Screen
    */
    test(
        "should not advance from Choose Cups Screen with letter for cup amount",
        () async {
      // final cups = find.byValueKey('cups-french-text-field');
      // await driver.tap(cups);
      // await driver.enterText('a');
      // await driver.waitFor(find.text('a'));
      // final gotofinalfrenchscreen = find.byValueKey('continue-french-button');
      // await driver.tap(gotofinalfrenchscreen);

      // final cupsScreen = find.byValueKey('cups-message');
      // expect(await driver.getText(cupsScreen), 'How many cups would you like?');

      // //finish going through french press to now test drip screens
      // final cupsCorrect = find.byValueKey('cups-french-text-field');
      // await driver.tap(cupsCorrect);
      // await driver.enterText('1');
      // await driver.waitFor(find.text('1'));
      // final gotofinalfrenchscreenCorrect = find.byValueKey('continue-french-button');
      // await driver.tap(gotofinalfrenchscreenCorrect);

      // final done = find.byValueKey('done-button');
      // await driver.tap(done);
    });

    /*
      Given I chose "Drip Machine" on the Coffee Device Selection Screen
      And I advanced to the Choose Cups Screen
      When I press "Continue"
      Then I expect to still be on the Choose Cups Screen
    */
    test("should not advance from Choose Cups Screen without cups", ()
    async {
      // final dripMachineCoffee =find.byValueKey('drip-option');
      // await driver.tap(dripMachineCoffee);
      // final nextPageConitnue = find.byValueKey('continue-button');
      // await driver.tap(nextPageConitnue);

      // final gotofinaldripscreen = find.byValueKey('continue-drip-button');
      // await driver.tap(gotofinaldripscreen);
      // final cupsScreen = find.byValueKey('cups-message');
      // expect(await driver.getText(cupsScreen), 'How many cups would you like?');


    });

    /*
      Given I chose "Drip Machine" on the Coffee Device Selection Screen
      And I advanced to the Choose Cups Screen
      When I enter "-1"
      And I press "Continue"
      Then I expect to still be on the Choose Cups Screen
    */
    test("should not advance from Choose Cups Screen with negative cup amount",
        () async{
      // final cups = find.byValueKey('cups-drip-text-field');
      // await driver.tap(cups);
      // await driver.enterText('-1');
      // await driver.waitFor(find.text('-1'));

      // final gotofinaldripscreen = find.byValueKey('continue-drip-button');
      // await driver.tap(gotofinaldripscreen);
      // final cupsScreen = find.byValueKey('cups-message');
      // expect(await driver.getText(cupsScreen), 'How many cups would you like?');
    });

    /*
      Given I chose "Drip Machine" on the Coffee Device Selection Screen
      And I advanced to the Choose Cups Screen
      When I enter "a"
      And I press "Continue"
      Then I expect to still be on the Choose Cups Screen
    */
    test(
        "should not advance from Choose Cups Screen with letter for cup amount",
        ()async {
      // final cups = find.byValueKey('cups-drip-text-field');
      // await driver.tap(cups);
      // await driver.enterText('a');
      // await driver.waitFor(find.text('a'));

      // final gotofinaldripscreen = find.byValueKey('continue-drip-button');
      // await driver.tap(gotofinaldripscreen);
      // final cupsScreen = find.byValueKey('cups-message');
      // expect(await driver.getText(cupsScreen), 'How many cups would you like?');

      // //finish going through drip machine to now test back buttons
      // final cupsCorrect = find.byValueKey('cups-drip-text-field');
      // await driver.tap(cupsCorrect);
      // await driver.enterText('1');
      // await driver.waitFor(find.text('1'));
      // final gotofinalfrenchscreenCorrect = find.byValueKey('continue-drip-button');
      // await driver.tap(gotofinalfrenchscreenCorrect);

      // final done = find.byValueKey('done-button');
      // await driver.tap(done);
    });
  });

  group('Back Button', () {
    test("should work on all pages in the french press path", ()async{
      // final frenchPressCoffee =find.byValueKey('french-option');
      // await driver.tap(frenchPressCoffee);
      // final nextPageConitnue = find.byValueKey('continue-button');
      // await driver.tap(nextPageConitnue);

      // final cups = find.byValueKey('cups-french-text-field');
      // await driver.tap(cups);
      // await driver.enterText('5');
      // await driver.waitFor(find.text('5'));
      // final gotofinalfrenchscreen = find.byValueKey('continue-french-button');
      // await driver.tap(gotofinalfrenchscreen);

      // final backonce = find.byValueKey('back-button');
      // await driver.tap(backonce);
      // final backtwice = find.byValueKey('back-button');
      // await driver.tap(backtwice);
      // final firstpagecheck = find.byValueKey('device-screen');
      // expect(await driver.getText(firstpagecheck), 'What coffee maker are you using?');
    });

    test("should work on all pages in the drip machine path", ()async{
      // final frenchPressCoffee =find.byValueKey('drip-option');
      // await driver.tap(frenchPressCoffee);
      // final nextPageConitnue = find.byValueKey('continue-button');
      // await driver.tap(nextPageConitnue);

      // final cups = find.byValueKey('cups-drip-text-field');
      // await driver.tap(cups);
      // await driver.enterText('5');
      // await driver.waitFor(find.text('5'));
      // final gotofinalfrenchscreen = find.byValueKey('continue-drip-button');
      // await driver.tap(gotofinalfrenchscreen);

      // final backonce = find.byValueKey('back-button');
      // await driver.tap(backonce);
      // final backtwice = find.byValueKey('back-button');
      // await driver.tap(backtwice);
      // final firstpagecheck = find.byValueKey('device-screen');
      // expect(await driver.getText(firstpagecheck), 'What coffee maker are you using?');
    });
  });
}
